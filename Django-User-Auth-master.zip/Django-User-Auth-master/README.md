# User Authentication in Django

User login, logout and signup in Django
